python 3.7.7 
tkinter, filedialog

실행 파일은 dist directory에 있습니다. :)

<순서>
1.
Click the "find input file" button and find input.txt file
(enter the input.txt file vertically and without spaces and without '\n')
find input file button을 통해 input.txt를 찾아주세요
(input.txt file 입력은 세로로 입력 + 빈칸 없이 입력해주세요)
ex.
13
14
52
3
5


2. 
Select the sort types and bar size
정렬과 bar size를 선택해 주세요

3.
Click the "Make bar" button
Make bar 버튼을 눌러 bar를 만들어 주세요

4.
Click the "Start" button
Start 버튼을 누르면 정렬이 실행됩니다.

5.
After the sorting click the "Save result file" button
you can save the sorting data in ouput.txt
정렬이 끝난 뒤 Save result file을 누르면 
ouput.txt파일에 정렬된 값이 생성됩니다.

6.
If you want to other sort program 
you will click other sort type and do 3, 4, 5 
다른 정렬을 하고 싶으시면 그냥 다른 정렬을 선택하고 
Make bar을 다시 누르고 반복하면 됩니다.

*주의
정렬되는 동안 화면을 누르거나 값이 너무 많아지면 렉이 걸릴수 있습니다.
